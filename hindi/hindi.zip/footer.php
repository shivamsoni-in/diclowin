<footer id="footer">

<!-- <div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-contact">
        <h1 class="logo me-auto pb-2"><a href="index.php" ><img src="assets/img/Logo.png" alt="" width="60%"></a></h1>
        <p>
          Delhi<br>
          India <br><br>
          <strong>Phone:</strong> 888 2390 100<br>
          <strong>Email:</strong> info@diclowin.com<br>
        </p>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Useful Links</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="legacy.php">Legacy</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Products</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Contact</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Products</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="tablet.php">Diclowin Plus Tablet</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Diclowin Muscles Relaxant Spray</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Diclowin headache Balm</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Diclowin Carbofast GEL</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Diclowin Knee Oil</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-newsletter">
        <h4>Join Our Newsletter</h4>
        <p>For Latest Update</p>
        <form action="" method="post">
          <input type="email" name="email"><input type="submit" value="Subscribe">
        </form>
      </div>

    </div>
  </div>
</div> -->

<div class="container d-md-flex py-4">

  <div class="me-md-auto text-center text-md-start">
    <div class="copyright h5 pt-2">
      &copy; All Rights Reserved By <strong><span>Wings Pharma</span></strong>
    </div>
    <!-- <div class="credits">
      Designed by <a href="#">Magical Balloons</a>
    </div> -->
  </div>
  <div class="social-links text-center text-md-right pt-3 pt-md-0">
    <a href="https://twitter.com/diclowinplus" target="_blank" class="twitter"><i class="bx bxl-twitter"></i></a>
    <a href="https://www.facebook.com/diclowin" target="_blank" class="facebook"><i class="bx bxl-facebook"></i></a>
    <a href="https://www.instagram.com/diclowin" target="_blank" class="instagram"><i class="bx bxl-instagram"></i></a>
     <a href="https://www.youtube.com/playlist?list=PLcRv_YvbGc2RLH0RT4hPmDUU4uYaM4BLe"  target="_blank"  class="google-plus"><i class="bx bxl-youtube"></i></a>
    <a href="https://in.linkedin.com/company/wingspharma" target="_blank"  class="linkedin"><i class="bx bxl-linkedin"></i></a>
  </div>
</div>
</footer><!-- End Footer -->
<br class="mobile-display">
<!--<br class="mobile-display"> -->
<a href="https://api.whatsapp.com/send?phone=+917428372007&amp;text=Diclowin" class=" float d-flex align-items-center justify-content-center" target="_blank"><img src="assets/img/whatsapp.png" style="width:50px;" alt=""></a>
<!--<a href="https://api.whatsapp.com/send?phone=+917428372007&amp;text=Diclowin" class="float" target="_blank">-->
<!--<img src="assets/img/whatsapp.png" style="width:50px;" alt="">-->
<!--</a>-->

    <!--<div class="fixed-bottom mobile-display text-center">
        <div class="vsblock vsbtn p-2" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown">
          <button type="button" class="btn vswid fw-bold text-light vsf">Buy Now</button>
        </div>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
          <li><a class="dropdown-item" target="_blank" href="https://www.netmeds.com/prescriptions/diclowin-plus-tablet-10-s">Diclowin Plus Tablets</a></li>
          
          <li><a class="dropdown-item" target="_blank" href=" https://www.amazon.in/Wings-Diclowin-Knee-Oil-Targeted/dp/B089SLVSPS/">Knee Oil</a></li>
          
          <li><a class="dropdown-item" target="_blank" href="https://www.netmeds.com/prescriptions/diclowin-mr-muscle-relaxant-spray-40gm ">MR+ Spray</a></li>
          
          <li><a class="dropdown-item" target="_blank" href="https://www.apollopharmacy.in/otc/diclowin-headache-balm-12-gm ">Headache Balm</a></li>
          <li><a class="dropdown-item" target="_blank" href="https://www.amazon.in/Diclowin-Joint-Pain-Relief-Pack/dp/B07L8FSJV9/">Pain Relief Gel</a></li>
          <li><a class="dropdown-item" target="_blank" href="#">Diclowin AQ Injection</a></li>
        </ul>
    </div>-->
    
    
    <div class="fixed-bottom d-block d-lg-none w-100 text-center vsbtn">
      <a href="https://www.amazon.in/stores/DiCLOWiN/page/D726BE68-A07F-49DA-993E-E808BE4B7D74?ref_=ast_bln" target="_blank" >
        <button type="button" class="btn vswid fw-bold text-light vsf">Buy Now</button>
      </a>
    </div>
    
    
    

<!-- Vendor JS Files -->
<script src="../assets/vendor/aos/aos.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="../assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="../assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="../assets/js/main.js"></script>

</body>

</html>