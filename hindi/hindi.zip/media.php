  <?php include 'header.php';?>
  <br><br>
    <section id="services" class="services section-bg section-title">
      <h2 class="h2 text-uppercase">Media</h2>
        <div class="container">
          <div class="row gx-3 gy-2 justify-content-center">

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/85WHEIYoyvc?controls=0&&mute=1&playlist=85WHEIYoyvc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/OIFp1TOgvLE?controls=0&&mute=1&playlist=OIFp1TOgvLE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/RB1-IDueh3Y?controls=0&&mute=1&playlist=RB1-IDueh3Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/MsoOlBqryO8?controls=0&&mute=1&playlist=MsoOlBqryO8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/kd3_KQPYcu4?controls=0&&mute=1&playlist=kd3_KQPYcu4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/PYxSK7jcOUI?controls=0&&mute=1&playlist=PYxSK7jcOUI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/CacwLZHDBWI?controls=0&&mute=1&playlist=CacwLZHDBWI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/dznrzjTQ4tQ?controls=0&&mute=1&playlist=dznrzjTQ4tQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/yCrXo9fUnaI?controls=0&&mute=1&playlist=yCrXo9fUnaI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/wOJg4sdfYo8?controls=0&&mute=1&playlist=wOJg4sdfYo8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
                <iframe src="https://www.youtube.com/embed/37mAzbTPjLg?controls=0&&mute=1&playlist=37mAzbTPjLg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="video-container">
              <iframe src="https://www.youtube.com/embed/videoseries?list=PLcRv_YvbGc2TYsKXwmmkZB-LWuCuApQzi" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>
        </div>
    </section>
  <!-- ======= Footer ======= -->
  <?php include 'footer.php';?>
